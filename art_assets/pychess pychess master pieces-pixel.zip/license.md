Pixel by [therealqtpi](https://twitter.com/therealqtpi) licensed under [AGPLv3+](https://www.gnu.org/licenses/agpl-3.0.txt).
Obtained from [here](https://github.com/ornicar/lila/tree/master/public/piece).
